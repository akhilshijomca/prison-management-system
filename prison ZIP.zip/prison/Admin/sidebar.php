<li class="nav-item menu-open">
  <a href="index.php" class="nav-link active">
    <i class="nav-icon fas fa-tachometer-alt"></i>
    <p>
      Dashboard
    </p>
  </a>
</li>

<li class="nav-item">
  <a href="#" class="nav-link">
    <p>
      User Management
      <i class="fas fa-angle-left right"></i>
    </p>
  </a>
  <ul class="nav nav-treeview">

    <li class="nav-item">
      <a href="add-admin.php" class="nav-link">
        <i class="far fa-circle nav-icon"></i>
        <p>Add User</p>
      </a>
    </li>


    <li class="nav-item">
      <a href="edit_profile.php" class="nav-link">
        <i class="far fa-circle nav-icon"></i>
        <p>Edit Profile</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="edit-photo.php" class="nav-link">
        <i class="far fa-circle nav-icon"></i>
        <p>Edit Photo</p>
      </a>
    </li>

    <li class="nav-item">
      <a href="user-record.php" class="nav-link">
        <i class="far fa-circle nav-icon"></i>
        <p>Admin Record</p>
      </a>
    </li>

  </ul>
</li>

<li class="nav-item">
  <a href="leave_record.php" class="nav-link">
    <p>Leave Management </p>
  </a>
</li>



<li class="nav-item">
  <a href="changepassword.php" class="nav-link">
    <p>Change Password</p>
  </a>
</li>

<li class="nav-item">
  <a href="logout.php" class="nav-link">
    <i class="fa fa-sign-out-alt"></i>
    <p>
      Logout
    </p>
  </a>
</li>


<p class="text"></p>
<p class="text"></p>
<p class="text"></p>
<p class="text"></p>
<p class="text"></p>
<p class="text"></p>
<p class="text"></p>
<p class="text"></p>

</li>